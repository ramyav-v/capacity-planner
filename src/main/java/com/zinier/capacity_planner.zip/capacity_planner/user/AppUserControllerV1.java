package com.zinier.capacity_planner.user;

import com.zinier.capacity_planner.user.dto.AppUserDtoV1;
import com.zinier.capacity_planner.user.model.AppUserResponseModel;
import com.zinier.capacity_planner.user.service.AppUserServiceV1;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("${spring.data.rest.base-path}/v1/users")
@RequiredArgsConstructor
public class AppUserControllerV1 {

    private final AppUserServiceV1 service;

    @GetMapping
    public List<AppUserResponseModel> listAll() {
        return service.listAll();
    }

    @GetMapping("/{id}")
    public AppUserResponseModel getById(@PathVariable Long id) {
        return service.getById(id);
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public AppUserResponseModel create(@RequestBody AppUserDtoV1 request) {
        return service.create(request);
    }

    @PutMapping("/{id}")
    public AppUserResponseModel update(@PathVariable Long id, @RequestBody AppUserDtoV1 request) {
        return service.update(id, request);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}
